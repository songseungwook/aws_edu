<!DOCTYPE html>
<html>
<head>
    <title>Object Storage 연결 정보</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div id="header"><a href="/"><img src="https://static.toastoven.net/toast/resources/img/logo_nhn_cloud_color.svg" /></a></div>
    <hr></hr>
    <h1>Object Storage 연결 정보</h1><h4 style="color: white;"> https://kr2-api-object-storage.nhncloudservice.com</h4>
    <form action="token.php" method="post">
        <p>
            <label for="host">STORAGE_URL:</label> 
            <input type="text" id="STORAGE_URL" name="STORAGE_URL"> 
        </p>
        <p>
            <label for="host">TENANT_ID:</label>
            <input type="text" id="TENANT_ID" name="TENANT_ID">
        </p>
        <p>
            <label for="port">NHN Cloud ID:</label>
            <input type="text" id="USERNAME" name="USERNAME">
        </p>
        <p>
            <label for="user">Paassword:</label>
            <input type="password" id="PASSWORD" name="PASSWORD">
        </p>
        <p>
            <label for="host">CONTAINER_NAME:</label>
            <input type="text" id="CONTAINER_NAME" name="CONTAINER_NAME">
        </p>

        <button type="submit" class="btn">데이터 업로드</button>
    </form>
    </div>
</body>
</html>
