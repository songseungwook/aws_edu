<!DOCTYPE html>
<html>
<head>
    <title>웹 서버 IP 주소 확인</title>
    <!-- Link to Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="header">

    </div>

    <div class="container mt-5">
    <a href="/">
            <img src="https://static.toastoven.net/toast/resources/img/logo_nhn_cloud_color.svg" />
        </a>
        <h1>현재 웹 서버의 IP 주소: <?php echo $_SERVER['SERVER_ADDR']; ?></h1>
        <button class="btn btn-secondary" onclick="location.href='gallery.php'">Gallery Page</button>
        <button onclick="location.href='stress.php'" class="btn">Stress Test</button>
        <button class="btn btn-secondary" onclick="location.href='obj.php'">Objcet Upload</button>
        

    </div>
    <!-- Link to Bootstrap JavaScript (Optional: Only required if you use Bootstrap JavaScript components) -->
    <!-- Add this script tag at the end of the body section -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
